from django.apps import AppConfig


class MyhelloConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'myhello'
